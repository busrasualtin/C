#include <stdio.h>
#include <time.h>
#include "linked_list.h"

void print_int (void *p)
{
    int a = (int)p;
    printf("%d", a);
}

void linked_list_print(LINKED_LIST list, void (*print_data)(void *))
{
    LINKED_LIST_NODE walker;
    walker = list->head;
    while(walker != NULL) {
        print_data(walker->data);
        printf(" ");
        walker = walker->next;
    }
    printf("\n");
}

int linked_list_remove___nullablelist(LINKED_LIST list, int idx, void **pdata)
{
    LINKED_LIST_NODE walker, tmp;
    void *data;
    int i;
    int e;
    data = NULL;
    e = 0;
    if(idx == 0 && list->head != NULL) {
        tmp = list->head;
        list->head = tmp->next;
        data = tmp->data;
        free(tmp);
        e = 1;
    }
    else {
        walker = list->head;
        idx--;
        for(i=0; i<idx && walker->next!=NULL; i++) {
            walker = walker->next;
        }
        if(walker != NULL && walker->next != NULL) {
            tmp = walker->next;
            walker->next = tmp->next;
            data = tmp->data;
            free(tmp);
            e = 1;
        }
    }
    if(pdata != NULL) {
        *pdata = data;
    }
    return e;
}

/* ordered function was prepared in labwork */
int linked_list_is_ordered(LINKED_LIST a)
{
    LINKED_LIST_NODE node1 = a->head;
    if(node1 == NULL)
    {
        return 1;
    }
    LINKED_LIST_NODE node2 = node1->next;
    if(node2 == NULL)
    {
        return 1;
    }
    while(node2 != NULL)
    {
        if((int)node1->data > (int)node2->data )
        {
            return 0;
        }
        node1 =node1->next;
        node2= node2->next;
    }
    return 1;
}
//https://gist.github.com/muhammedeminoglu/b6e38c66d034374661e33fe191b846b0
void linked_list_node_swap (LINKED_LIST_NODE node_1, LINKED_LIST_NODE node_2){
    void *tmp = node_1->data;
    node_1->data = node_2->data;
    node_2->data = tmp;
} LINKED_LIST_NODE tmp;

void selection_sort(LINKED_LIST l){
    LINKED_LIST_NODE walker;
    walker = l->head;
    tmp = l->head;

    if(l->head == NULL && l->head->next == NULL){
        return;
    }
    while(walker != NULL)
    {
        tmp = walker -> next;
        while(tmp != NULL)
        {
            if((void *) walker->data > tmp->data)
            {
                linked_list_node_swap(walker, tmp);
            }
            tmp = tmp->next;
        }
        walker = walker->next;
    }
}

int main()
{
    LINKED_LIST l = linked_list_init();
    srand(time(NULL));
    int i,m;

    //random 10 integer values..
    printf("numbers:\n");
    for(i=0;i<10;i++){
        m=rand()%50;
        linked_list_prepend(l,(void*)m);
    }

/*  printf("remove: 0\n");
	linked_list_remove(l, 0);
	linked_list_print(l, &print_int);

    printf("prepend: 7 times\n");
    linked_list_prepend(l, (void *)0);
    linked_list_prepend(l, (void *)21);
    linked_list_prepend(l, (void *)2);
    linked_list_prepend(l, (void *)3);
    linked_list_prepend(l, (void *)4);
    linked_list_prepend(l, (void *)15);
    linked_list_prepend(l, (void *)65); */

    linked_list_append(l, (void *)12);
    //linked_list_insert(l, (void *)0, 4);
    //linked_list_removeall(l);
    //linked_list_get(l,1);
    linked_list_print(l, &print_int);


    printf("before sorting \n");
    linked_list_print(l,&print_int);

    selection_sort(l);

    printf("after sorting \n");
    linked_list_print(l, &print_int);

    /*  printf("remove: -1, 7\n");
    linked_list_remove(l, -1);
    linked_list_remove(l, 7);
    linked_list_print(l, &print_int);

    printf("remove: 3\n");
    linked_list_remove(l, 3);
    linked_list_print(l, &print_int);

    printf("remove: 0\n");
    linked_list_remove(l, 0);
    linked_list_print(l, &print_int);

    printf("remove: 4\n");
    linked_list_remove(l, 4);
    linked_list_print(l, &print_int);

    printf("remove: 0,0,0\n");
    linked_list_remove(l, 0);
    linked_list_remove(l, 0);
    linked_list_remove(l, 0);
    linked_list_print(l, &print_int);

    printf("remove: 0\n");
    linked_list_remove(l, 0);
    linked_list_print(l, &print_int);

    printf("remove: 0\n");
    linked_list_remove(l, 0);
    linked_list_print(l, &print_int);

    linked_list_free(l);  */

    return 0;
}